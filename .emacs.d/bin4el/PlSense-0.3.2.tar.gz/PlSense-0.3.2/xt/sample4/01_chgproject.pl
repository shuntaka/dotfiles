#!/usr/bin/perl

use String::Random qw{ random_string };

# astart installed module in carton project
#&random_
# aend equal: random_string

