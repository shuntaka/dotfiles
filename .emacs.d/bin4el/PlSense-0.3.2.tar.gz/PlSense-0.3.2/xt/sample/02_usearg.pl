#!/usr/bin/perl

use List::AllUtils;


# astart use base
#use base qw{ 
# aend include: Exporter Getopt::Long
# aend exclude: grep _ ARGV ENV

# astart use parent
#use parent qw{ 
# aend include: Exporter Getopt::Long
# aend exclude: grep _ ARGV ENV

# astart choice import
#use List::AllUtils qw{ 
# aend include: first all uniq :all
# aend exclude: Exporter grep _ ARGV ENV

# astart choice import has word
#use List::AllUtils qw{ uniq 
# aend include: first all :all
# aend exclude: uniq
# ahelp max : ^ max \s is \s Method \s of \s List::AllUtils\. $
# ahelp max : ^ RETURN: \s
# ahelp max : ^ \s* max \s+ LIST \s

