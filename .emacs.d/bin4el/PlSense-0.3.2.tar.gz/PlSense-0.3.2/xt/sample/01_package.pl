#!/usr/bin/perl

use File::Basename;


# astart use
#use 
# aend include: Exporter File::Spec Getopt::Long strict warnings
# aend exclude: grep map shift $_ @ARGV %ENV

# astart require
#require 
# aend include: Exporter File::Spec Getopt::Long strict warnings
# aend exclude: grep map shift $_ @ARGV %ENV

# astart use has word
#use Fi
# aend include: File::Spec File::Basename FindBin
# aend exclude: Exporter Getopt::Long strict warnings

# astart package word
#Fi
# aend include: File::Spec File::Basename FindBin
# aend exclude: Exporter Getopt::Long strict warnings
# ahelp File::Basename : ^ File::Basename \s is \s Module\. $
# ahelp File::Basename : ^ defined \s in \s ' [^']+ ' \. $
# ahelp File::Basename : ^ NAME \s+ File::Basename \s+ - \s
# ahelp File::Basename : ^ \s* "basename" \s
# ahelp File::Basename : ^ \s* "dirname" \s


# hstart package
#use File::Basename
# hend ^ File::Basename \s is \s Module\. $
# hend ^ defined \s in \s ' [^']+ ' \. $
# hend ^ NAME \s+ File::Basename \s+ - \s
# hend ^ \s* "basename" \s
# hend ^ \s* "dirname" \s

