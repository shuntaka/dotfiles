#!/usr/bin/perl

use vars ('$hoge');

# astart use vars by brace
#$
# aend include: hoge

